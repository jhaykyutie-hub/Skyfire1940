# Skyfire 1940 — Android project

An original, lightweight low-poly-inspired WWII arcade flight-combat game. It uses a custom canvas renderer and does not copy the original game's code, models, branding, or artwork.

## Build an APK
1. Install Android Studio (current stable) and the Android SDK Platform 35.
2. Open this folder (`Skyfire1940Android`) in Android Studio.
3. Let Gradle sync and install any prompted SDK components.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

The app runs the included game locally in an Android WebView; no internet permission or server is needed.

## Controls
- Touch: drag the left steering pad; hold FIRE; hold BOOST.
- Keyboard: WASD or arrow keys, Space to fire, Shift to boost.
